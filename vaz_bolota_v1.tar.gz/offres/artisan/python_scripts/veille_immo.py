import json
import time
import random

def get_opportunities():
    return [
        {"nom": "SCI DU PARC", "tel": "0145678910", "email": "info@sciparc.fr", "projet": "Rénovation Toiture"},
        {"nom": "M. JEAN DUPONT", "tel": "0600112233", "email": "j.dupont@email.com", "projet": "Installation Électrique"}
    ]

if __name__ == "__main__":
    print(json.dumps(get_opportunities()))
