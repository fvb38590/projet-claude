import re
import sys
import json

def clean_artisan_data(data):
    name = data.get("nom", "Client").strip().title()
    phone = re.sub(r'\D', '', data.get("tel", ""))
    if phone.startswith("33"): phone = "0" + phone[2:]
    if len(phone) == 9 and phone.startswith('6'): phone = "0" + phone
    return {"nom": name, "tel": phone, "email": data.get("email", "").lower().strip(), "projet": data.get("projet", "N/A")}

if __name__ == "__main__":
    input_data = json.loads(sys.stdin.read()) if not sys.stdin.isatty() else {}
    print(json.dumps(clean_artisan_data(input_data)))
