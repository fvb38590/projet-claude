import json
import sys
from fpdf import FPDF

def generate_pdf(json_input):
    try:
        data = json.loads(json_input)
        if not isinstance(data, list): data = [data]
    except:
        data = [{"nom": "Erreur", "tel": "N/A", "projet": "Données invalides"}]

    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", 'B', 16)
    pdf.cell(0, 10, "Bilan Opportunités - Vaz Bolota", ln=True, align='C')
    pdf.ln(10)
    for lead in data:
        pdf.set_font("Arial", 'B', 12)
        pdf.cell(0, 10, f"PROJET : {lead.get('projet')}", ln=True)
        pdf.set_font("Arial", '', 11)
        pdf.cell(0, 8, f"Nom : {lead.get('nom')} | Tel : {lead.get('tel')}", ln=True)
        pdf.ln(5)
    
    path = "offres/artisan/demo_docs/dernier_rapport.pdf"
    pdf.output(path)
    print(path)

if __name__ == "__main__":
    generate_pdf(sys.stdin.read() if not sys.stdin.isatty() else "[]")
