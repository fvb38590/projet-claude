import sys
import json

def format_for_compta(raw_data):
    processed = []
    for item in raw_data:
        item["code_journal"] = "ACH"
        item["compte_general"] = "606000"
        processed.append(item)
    return processed

if __name__ == "__main__":
    data = json.loads(sys.stdin.read()) if not sys.stdin.isatty() else []
    print(json.dumps(format_for_compta(data)))
