import json
import sys

def validate_docs(client_data):
    required = ["ID_Recto", "ID_Verso", "Justificatif_Domicile"]
    results = {doc: "Validé" for doc in required}
    
    if client_data.get("nom") == "Incomplet":
        results["Justificatif_Domicile"] = "Manquant"
        
    return {
        "client": client_data.get("nom", "Inconnu"),
        "statut_global": "OK" if "Manquant" not in results.values() else "Incomplet",
        "details": results
    }

if __name__ == "__main__":
    input_str = sys.stdin.read() if not sys.stdin.isatty() else "{}"
    data = json.loads(input_str)
    print(json.dumps(validate_docs(data)))
