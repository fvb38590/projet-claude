import json
import random

def get_invoices():
    return [
        {"fournisseur": "Orange Business", "montant_ht": 145.50, "tva": 29.10, "date": "2023-10-27"},
        {"fournisseur": "EDF Pro", "montant_ht": 890.00, "tva": 178.00, "date": "2023-10-26"}
    ]

if __name__ == "__main__":
    print(json.dumps(get_invoices()))
