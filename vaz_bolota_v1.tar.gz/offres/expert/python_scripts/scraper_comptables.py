import requests
import time
import random

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36"
]

def fetch_prospects(city="Paris"):
    print(f"🔍 Recherche d'experts-comptables à {city}...")
    headers = {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept-Language": "fr-FR,fr;q=0.9"
    }
    
    time.sleep(random.uniform(1.5, 3.0))
    
    results = [
        {"nom": "Cabinet Durand", "email": "contact@durand-compta.fr", "status": "Lead"},
        {"nom": "Lefebvre Associés", "email": "admin@lefebvre.com", "status": "Lead"}
    ]
    
    for r in results:
        print(f"✅ Trouvé : {r['nom']} ({r['email']})")

if __name__ == "__main__":
    fetch_prospects()
